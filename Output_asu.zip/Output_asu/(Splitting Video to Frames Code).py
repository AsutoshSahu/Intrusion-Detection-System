import cv2
import os

def split_video_into_frames(video_path, output_folder, n_frames):
    # Open the video file
    cap = cv2.VideoCapture(video_path)

    # Get the frames per second (fps) and total number of frames
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    # Calculate the step to evenly sample n_frames
    step = total_frames // n_frames
    print(step)

    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    # Loop through the video and save frames
    frame_count = 0
    while True:
        
        ret, frame = cap.read()

        if not ret:
            break

        # Save frame if it's at the specified step
        if frame_count % step == 0:
            
            frame_filename = os.path.join(output_folder, f"frame_{frame_count}.jpg")
            cv2.imwrite(frame_filename, frame)

        frame_count += 1

    # Release the video capture object
    cap.release()
    

    print(f"{n_frames} frames saved in {output_folder}")

# Example usage
video_path = "C:\\Users\\sahua\\Downloads\\EE722\\qno3_input\\IITG_CORE2_Clip.mp4"
output_folder = "C:\\Users\\sahua\\Downloads\\EE722\\qno3_output"
n_frames = 15  # Change this to the desired number of frames

split_video_into_frames(video_path, output_folder, n_frames)
