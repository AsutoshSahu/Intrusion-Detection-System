import cv2
import numpy as np
import os


def read_images(image_dir_path):
    files = os.listdir(image_dir_path)
    imgs = []
    for file in files:
        img_path = os.path.join(image_dir_path,file)
        img = cv2.imread(img_path)
        imgs.append(img)
    return imgs

def initBackgroundModel(img, initVar):
    # Convert the image to floating-point format for accurate calculations
    img_float = img.astype(np.float32)

    # Initialize mean and variance arrays
    mean_values = np.mean(img_float, axis=(0, 1))
    var_values = np.var(img_float, axis=(0, 1))
    meanBakImg = (np.ones((img.shape)))*mean_values
    varBakImg = (np.ones((img.shape)))*var_values
    return meanBakImg, varBakImg

def foregroundExtraction(current_img, ref_mean, ref_var, lambda_val):
    det = np.subtract(current_img,ref_mean)
    h,w,_ = current_img.shape
    c = np.zeros(current_img.shape)
    cc = np.ones((h,w))
    
    for x in range(h):
        for y in range(w):
            for k in range(3):
                c[x,y,k] = ((det[x,y,k]**2) <= ((lambda_val**2)*(ref_var[x,y,k])))
            cc[x,y] = c[x,y,0] and c[x,y,1] and c[x,y,2]

    d = np.where(cc == 0, cc+1, cc-1)
    
    change_img = np.zeros(current_img.shape)
    change_img = 255*d
    

    return change_img
ref_img = cv2.imread('C:\\Users\\sahua\\Downloads\\EE722\\Images\\AirstripRunAroundFeb2006_1300.bmp')
curr_img = cv2.imread('C:\\Users\\sahua\\Downloads\\EE722\\Images\\AirstripRunAroundFeb2006_1301.bmp')
initVar = 10  # Adjust this value based on your requirements

meanBakImg, varBakImg = initBackgroundModel(ref_img, initVar)
lambda_val = 3
foreground_mask = foregroundExtraction(curr_img, meanBakImg, varBakImg, lambda_val)
print(foreground_mask.shape)
# cv2.imshow('Mean',meanBakImg)
# cv2.imshow('Var',varBakImg)
# cv2.imshow('fgm',foreground_mask)
# cv2.waitKey(0)                                                  
# cv2.destroyAllWindows()


def voting(noisy_mask, m, vote_th, num):
    # Create a copy of the noisy mask to store the clean mask

    #clean_mask = np.copy(foreground_mask)

    # Get the height and width of the mask
    
    height, width = noisy_mask.shape
    w_count = 0
    vote_img = np.zeros(noisy_mask.shape)
    # Traverse the mask image pixel by pixel
    for x in range(m,height-m):
        for y in range(m,width-m):
            for i in range(x-m,x+m+1):
                for j in range(y-m,y+m+1):
                    if noisy_mask[i,j]==num:
                        w_count+=1

            if w_count >= (vote_th*((2*m+1)**2)):
                vote_img[x,y]=num
            w_count = 0

          
    return vote_img
        
def updateBackgroundModel(cIt, It, mean_old, var_old, alpha):

    det = It - mean_old

    h,w,_ = It.shape
    mean_new = np.zeros(mean_old.shape)
    var_new = np.zeros(var_old.shape)

    
    for x in range(h):
        for y in range(w):
            for k in range(3):
                #mean_new[x,y,k] = (1-alpha)*mean_old[x,y,k]+alpha*It[x,y,k]
                mean_new[x,y,k]= mean_old[x,y,k]+alpha*det[x,y,k]
                var_new[x,y,k] = (1-alpha)*(var_old[x,y,k]+alpha*det[x,y,k]*2)
    
    # Implement your logic to update the background model
    # Return the updated mean and variance of the background model
    #print(mean_new)
    return mean_new,var_new

def detect_shadow(ref_img, curr_img, clean_mask, epsilon):
    h,w,_ = ref_img.shape
    one_arr = np.ones(ref_img.shape)
    ref_img = ref_img+one_arr
    eta = curr_img/ref_img
    h,w,_ = ref_img.shape
    eta_a = np.zeros(ref_img.shape)
    eta_b = np.zeros(ref_img.shape)
    shadow_m = np.zeros((h,w))
    for x in range(h):
        for y in range(w):
            eta_a = (eta[x,y,0]<1)and(eta[x,y,1]<1)and(eta[x,y,2]<1)
            eta_b = (abs(eta[x,y,0]-eta[x,y,1]) < epsilon)and(abs(eta[x,y,1]-eta[x,y,2]) < epsilon)and(abs(eta[x,y,2]-eta[x,y,0]) < epsilon)
            if eta_a and eta_b:
                shadow_m[x,y] = 128
    return shadow_m


# AIRSTRIP
image_dir_path = "C:\\Users\\sahua\\Downloads\\EE722\\Images"
img_arr = read_images(image_dir_path)
ref_img = img_arr[0]
meanBakImg, varBakImg = initBackgroundModel(ref_img, initVar)
initVar = 10  # Adjust this value based on your requirements
for i in range(1,11):
    curr_img = img_arr[i*5]
    lambda_val = 3
    foreground_mask = foregroundExtraction(curr_img, meanBakImg, varBakImg, lambda_val)
    noise_removal = voting(foreground_mask, 2, 0.6, 255)
    meanBakImg,varBakImg = updateBackgroundModel(foreground_mask, curr_img, meanBakImg, varBakImg, 0.01)
    shadow = detect_shadow(ref_img, curr_img, noise_removal, 0.5)
    print(shadow.shape)
    shadow_noise_removal = voting(shadow, 3, 0.7, 128)
    final = noise_removal+shadow_noise_removal
    h,w = final.shape
    for x in range(h):
        for y in range(w):
            if final[x,y] == 255:
                final[x,y] = 0
    cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\fg_mask_{i}.png", foreground_mask)
    cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\clean_mask_{i}.png", noise_removal)
    cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\shadow_{i}.png", shadow_noise_removal)
    cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\final_{i}.png", final)


# PHONE VIDEO
image_dir_path = "C:\\Users\\sahua\\Downloads\\EE722\\qno3_output"
img_arr = read_images(image_dir_path)
ref_img = img_arr[0]
meanBakImg, varBakImg = initBackgroundModel(ref_img, initVar)
initVar = 10  # Adjust this value based on your requirements
for i in range(1,11):
    curr_img = img_arr[i]
    lambda_val = 1.5
    foreground_mask = foregroundExtraction(curr_img, meanBakImg, varBakImg, lambda_val)
    noise_removal = voting(foreground_mask, 3, 0.4, 255)
    meanBakImg,varBakImg = updateBackgroundModel(foreground_mask, curr_img, meanBakImg, varBakImg, 0.01)
    # shadow = detect_shadow(ref_img, curr_img, noise_removal, 0.5)
    # print(shadow.shape)
    # shadow_noise_removal = voting(shadow, 2, 0.5, 128)
    # final = noise_removal+shadow_noise_removal
    # h,w = final.shape
    # for x in range(h):
    #     for y in range(w):
    #         if final[x,y] == 255:
    #             final[x,y] = 0
    cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\foreground_mask_{i}.png", foreground_mask)
    cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\clean_mask_{i}.png", noise_removal)
    # cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\shadow_{i}.png", shadow_noise_removal)
    # cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\final_{i}.png", final)



# WEBCAM
image_dir_path = "C:\\Users\\sahua\\Downloads\\EE722\\Webcam"
img_arr = read_images(image_dir_path)
ref_img = img_arr[0]
meanBakImg, varBakImg = initBackgroundModel(ref_img, initVar)
initVar = 10  # Adjust this value based on your requirements
for i in range(1,11):
    curr_img = img_arr[i]
    lambda_val = 3
    foreground_mask = foregroundExtraction(curr_img, meanBakImg, varBakImg, lambda_val)
    noise_removal = voting(foreground_mask, 2, 0.6, 255)
    meanBakImg,varBakImg = updateBackgroundModel(foreground_mask, curr_img, meanBakImg, varBakImg, 0.01)
    shadow = detect_shadow(ref_img, curr_img, noise_removal, 0.5)
    print(shadow.shape)
    shadow_noise_removal = voting(shadow, 2, 0.6, 128)
    final = noise_removal+shadow_noise_removal
    h,w = final.shape
    for x in range(h):
        for y in range(w):
            if final[x,y] == 255:
                final[x,y] = 0
    # cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\fg_mask_{i}.png", foreground_mask)
    # cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\clean_mask_{i}.png", noise_removal)
    cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\shadow_{i}.png", shadow_noise_removal)
    cv2.imwrite(f"C:\\Users\\sahua\\Downloads\\EE722\\OutputFGBG\\final_{i}.png", final)